from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
from typing import List
import os

app = FastAPI()

# model file must be in the same directory as this script
MODEL_PATH = os.path.join(os.path.dirname(__file__), "model.pkl")
model = joblib.load(MODEL_PATH)

class InputData(BaseModel):
    features: List[float]  

@app.post("/predict")
def predict(data: InputData):
    X = np.array(data.features, dtype=np.float32).reshape(1, -1)
    preds = model.predict(X)
    return {"predictions": preds.tolist()}